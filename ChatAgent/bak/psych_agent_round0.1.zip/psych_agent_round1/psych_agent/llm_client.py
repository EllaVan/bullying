"""可选的非流式对话适配器。默认离线；只有extract显式选择LLM才联网。"""
import json
import os
import socket
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from .io_utils import ValidationError, parse_json


class NoRedirect(HTTPRedirectHandler):
    # 不将Bearer密钥随重定向发到其他地址。
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def call_chat(messages, settings):
    if not isinstance(settings, dict):
        raise ValidationError('LLM配置必须是JSON对象')
    endpoint = settings.get('endpoint', '')
    model = settings.get('model', '')
    if not isinstance(endpoint, str) or not isinstance(model, str) or not model.strip():
        raise ValidationError('请在LLM配置填写完整endpoint和账号实际可用的model')
    try:
        parsed = urlsplit(endpoint)
    except ValueError:
        raise ValidationError('endpoint地址格式错误') from None
    local = parsed.hostname in {'localhost', '127.0.0.1', '::1'}
    if parsed.scheme not in ({'https','http'} if local else {'https'}) or not parsed.hostname:
        raise ValidationError('远程LLM endpoint必须使用HTTPS；HTTP仅允许本机回环地址')
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValidationError('endpoint不能包含用户名、密码、查询参数或片段；密钥只从环境变量读取')
    timeout = settings.get('timeout_seconds', 45)
    if type(timeout) not in (int, float) or not 1 <= timeout <= 60:
        raise ValidationError('timeout_seconds必须在1到60之间')
    json_mode = settings.get('json_object_mode', False)
    if type(json_mode) is not bool:
        raise ValidationError('json_object_mode必须为布尔值')
    env_name = settings.get('api_key_env', 'PSYCH_LLM_API_KEY')
    if not isinstance(env_name, str) or not env_name:
        raise ValidationError('api_key_env必须是环境变量名')
    api_key = os.environ.get(env_name, '')
    if not api_key and not local:
        raise ValidationError(f'尚未设置环境变量{env_name}，未发出任何API请求')
    body = {'model':model, 'messages':messages, 'stream':False}
    if json_mode:
        body['response_format'] = {'type':'json_object'}
    headers = {'Content-Type':'application/json'}
    if api_key:
        headers['Authorization'] = 'Bearer ' + api_key
    request = Request(endpoint, data=json.dumps(body, ensure_ascii=False).encode('utf-8'), headers=headers, method='POST')
    try:
        with build_opener(NoRedirect()).open(request, timeout=timeout) as response:
            wire = response.read(4_000_001)
        if len(wire) > 4_000_000:
            raise ValidationError('模型响应超过本实验允许的大小')
        payload = parse_json(wire.decode('utf-8'))
    except HTTPError as exc:
        raise ValidationError(f'LLM请求失败，HTTP状态码{exc.code}；请检查账号、endpoint及模型配置') from None
    except (URLError, TimeoutError, socket.timeout, OSError):
        raise ValidationError('LLM请求超时或网络连接失败；没有自动重复请求') from None
    except UnicodeDecodeError:
        raise ValidationError('LLM接口返回的内容不是UTF-8文本') from None
    try:
        choice = payload['choices'][0]
        content = choice['message']['content']
    except (TypeError, KeyError, IndexError):
        raise ValidationError('LLM响应不符合choices[0].message.content协议；需要调整适配器') from None
    if choice.get('finish_reason') not in (None, 'stop'):
        raise ValidationError('模型响应未正常结束或被截断，不能用于证据汇总')
    if not isinstance(content, str) or not content.strip():
        raise ValidationError('LLM未返回可解析的文本内容')
    return content
