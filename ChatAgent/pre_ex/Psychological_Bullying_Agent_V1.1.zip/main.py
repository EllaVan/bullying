
from agents.pipeline import scenario, interview, evidence, reasoning

s=scenario()
print("情景:")
print(s)

a=input("回答:")
i=interview(s,a)

e=evidence(s,a)

print("Evidence:")
print(e)

r=reasoning(e)

print("Risk:")
print(r)
