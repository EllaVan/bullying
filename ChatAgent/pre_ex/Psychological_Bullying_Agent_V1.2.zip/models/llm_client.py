
import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

client=OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
MODEL=os.getenv("OPENAI_MODEL","gpt-4.1-mini")

def call_llm(system,payload):
    r=client.chat.completions.create(
        model=MODEL,
        temperature=0.2,
        response_format={"type":"json_object"},
        messages=[
        {"role":"system","content":system},
        {"role":"user","content":payload}
        ])
    return r.choices[0].message.content
